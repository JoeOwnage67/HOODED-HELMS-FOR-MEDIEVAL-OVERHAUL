#MOHoodedHelms
WIP addon for Medieval Overhaul

- Adds hooded variations for most of Medieval Overhaul's helms.
- Adds winter hooded variations in four colours for most of Medieval Overhaul's helms if Dusk Armory is detected as installed. (uses art from Dusk)

