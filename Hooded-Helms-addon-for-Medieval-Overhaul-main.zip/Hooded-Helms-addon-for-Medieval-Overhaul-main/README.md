#MOHoodedHelms
WIP addon for Medieval Overhaul - released on Steam due to imminent release of 1.4

- Adds hooded variations for most of Medieval Overhaul's helms.
- Adds winter hooded variations in four colours for most of Medieval Overhaul's helms if Dusk Armory is detected as installed. (uses art from Dusk)

